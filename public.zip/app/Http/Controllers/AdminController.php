<?php

namespace App\Http\Controllers;

use App\Http\Middleware\Admin;
use App\Models\Admin as ModelsAdmin;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class AdminController extends Controller
{
}
