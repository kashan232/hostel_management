<div class="footer footer-outer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Kashan Shaikh</a> 2024</p>
            </div>
        </div>